import torch
import torchvision
from utils import *

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

image_dir = 'output\\dog1\\suc_251.jpg'

attack_X = preprocess(image_dir).to(device)

pretrained_net = torchvision.models.vgg19(pretrained=True)

pred = pretrained_net(attack_X)

print_prob(pred[0].detach().cpu().numpy(), 'synset.txt')