import torch
import torchvision
from utils import *
from options import args

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

image_dir = args.image_dir

attack_X = preprocess(image_dir).to(device)

pretrained_net = torchvision.models.vgg19(pretrained=True)

pred = pretrained_net(attack_X)

print_prob(pred[0].detach().cpu().numpy(), 'synset.txt')