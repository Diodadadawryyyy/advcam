import torch
import torchvision
from torch import nn
import torch.nn.functional as F
import os
from utils import *


# 设置设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 加载和预处理图像
content_image_path = 'physical-attack-data\\content\\1\\5.jpeg'
style_image_path = 'physical-attack-data\\style\\oil-painting\\1.jpg'
output_dir = 'output\\5'

# 定义内容层和风格层
style_layers, content_layers = [1, 6, 11, 20, 29], [22]

# 加载预训练的VGG19模型
pretrained_net = torchvision.models.vgg19(pretrained=True)

net = nn.Sequential(*[pretrained_net.features[i] for i in
                      range(max(content_layers + style_layers) + 1)])

def postprocess(img):
    img = img[0].to(rgb_std.device)
    img = torch.clamp(img.permute(1, 2, 0) * rgb_std + rgb_mean, 0, 1)
    return torchvision.transforms.ToPILImage()(img.permute(2, 0, 1))

def extract_features(X, content_layers, style_layers):
    contents = []
    styles = []
    for i in range(len(net)):
        X = net[i](X)
        if i in style_layers:
            styles.append(X)
        if i in content_layers:
            contents.append(X)
    return contents, styles

def get_contents(device):
    content_X = preprocess(content_image_path).to(device)
    contents_Y, _ = extract_features(content_X, content_layers, style_layers)
    return content_X, contents_Y

def get_styles(device):
    style_X = preprocess(style_image_path).to(device)
    _, styles_Y = extract_features(style_X, content_layers, style_layers)
    return style_X, styles_Y

def content_loss(Y_hat, Y):
    # 我们从动态计算梯度的树中分离目标：
    # 这是一个规定的值，而不是一个变量。
    return torch.square(Y_hat - Y.detach()).mean()

def gram(X):
    num_channels, n = X.shape[1], X.numel() // X.shape[1]
    X = X.reshape((num_channels, n))
    return torch.matmul(X, X.T) / (num_channels * n)

def style_loss(Y_hat, gram_Y):
    return torch.square(gram(Y_hat) - gram_Y.detach()).mean()

# def tv_loss(Y_hat):
#     return 0.5 * (torch.abs(Y_hat[:, :, 1:, :] - Y_hat[:, :, :-1, :]).mean() +
#                   torch.abs(Y_hat[:, :, :, 1:] - Y_hat[:, :, :, :-1]).mean())

layer_structure_all = [layer for layer in net]

def targeted_attack_loss(pred, orig_pred, target):
    """
    Note:
        balance can be adjusted by user for better results, range in [2,5] is recommended
    Arguments:
        pred {logits} -- Logits output by threat model (input: adv) 
        orig_pred {int} --  Original (correct) prediction by threat model
        target {int} -- Target lable assigned by user, range in [0,999]
    
    Returns:
        [type] -- [description]
    """
    balance = 5
    if orig_pred.is_cuda:
        eye = torch.eye(1000).cuda()
    else:
        eye = torch.eye(1000)
    orig_pred = eye[orig_pred]
    target = eye[target]
    target = target.unsqueeze(0)
    # loss1 = -1 * F.cross_entropy(pred, orig_pred, reduction='sum')
    loss2 = F.cross_entropy(pred, target, reduction='sum')
    loss_attack = torch.sum(loss2)
    return loss_attack

content_weight, style_weight, attack_weight = 5e0, 5e3, 5e3

def compute_loss(X, contents_Y_hat, styles_Y_hat, contents_Y, styles_Y_gram, pred, orig_pred, target):
    # 分别计算内容损失、风格损失和全变分损失
    contents_l = [content_loss(Y_hat, Y) * content_weight for Y_hat, Y in zip(
        contents_Y_hat, contents_Y)]
    styles_l = [style_loss(Y_hat, Y) * style_weight for Y_hat, Y in zip(
        styles_Y_hat, styles_Y_gram)]
    attack_l = [targeted_attack_loss(pred, orig_pred, target)* attack_weight]
    # 对所有损失求和
    l = sum(styles_l + contents_l + attack_l)
    return contents_l, styles_l, attack_l, l

class SynthesizedImage(nn.Module):
    def __init__(self, img_shape, **kwargs):
        super(SynthesizedImage, self).__init__(**kwargs)
        self.weight = nn.Parameter(torch.rand(*img_shape))

    def forward(self):
        return self.weight

def get_inits(X, device, lr, styles_Y):
    gen_img = SynthesizedImage(X.shape).to(device)
    gen_img.weight.data.copy_(X.data)
    trainer = torch.optim.Adam(gen_img.parameters(), lr=lr)
    styles_Y_gram = [gram(Y) for Y in styles_Y]
    return gen_img(), styles_Y_gram, trainer

def train(X, contents_Y, styles_Y, device, lr, num_epochs, lr_decay_epoch, orig_pred, target):
    X, styles_Y_gram, trainer = get_inits(X, device, lr, styles_Y)
    scheduler = torch.optim.lr_scheduler.StepLR(trainer, lr_decay_epoch, 0.8)
    for epoch in range(num_epochs+1):
        trainer.zero_grad()
        contents_Y_hat, styles_Y_hat = extract_features(
            X, content_layers, style_layers)
        pred = pretrained_net(X)
        pred_print = pred.detach().cpu().numpy()
        pred_label = torch.argmax(pred, dim=1)
        contents_l, styles_l, attack_l, l = compute_loss(
            X, contents_Y_hat, styles_Y_hat, contents_Y, styles_Y_gram, pred, orig_pred, target)
        l.backward()
        trainer.step()
        scheduler.step()

        # 打印信息
        print(f"Iteration {epoch+1}/{num_epochs}")
        print(f"\tContent loss: {sum(contents_l)}")
        print(f"\tStyle loss: {sum(styles_l)}")
        print(f"\tAttack loss: {attack_l[0]}")
        print(f"\tTotal loss: {l}")

        # 保存图像
        if epoch % 50 == 0:
            output_image = postprocess(X)
            # 获取内容图像名称
            content_image_name = os.path.basename(content_image_path).split('.')[0]
            # 初始化成功标志
            suc = 'non'

            if pred_label == target:
                suc = 'suc'
            print_prob(pred_print[0], 'synset.txt')
            # 保存结果
            save_result(output_image, os.path.join(output_dir, f'{suc}_{epoch+1}.jpg')) 

    return X

pretrained_net = pretrained_net.to(device)
net = net.to(device)
content_X, contents_Y = get_contents(device)
_, styles_Y = get_styles(device)
orig_pred = pretrained_net(content_X)
orig_pred_label = torch.argmax(orig_pred, dim=1)
print_prob(orig_pred[0].detach().cpu().numpy(), 'synset.txt')
target = 498
output = train(content_X, contents_Y, styles_Y, device, 0.3, 500, 50, orig_pred_label, target)