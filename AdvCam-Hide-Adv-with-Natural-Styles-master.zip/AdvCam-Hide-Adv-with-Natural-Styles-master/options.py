import argparse

# 定义命令行参数
parser = argparse.ArgumentParser(description='Style Transfer with Targeted Attack')
parser.add_argument('--content_image_path', type=str, default='physical-attack-data\\content\\1\\5.jpeg', help='Path to content image')
parser.add_argument('--style_image_path', type=str, default='physical-attack-data\\style\\oil-painting\\1.jpg', help='Path to style image')
parser.add_argument('--output_dir', type=str, default='output\\5', help='Output directory for results')
parser.add_argument('--content_layers', nargs='+', type=int, default=[1, 6, 11, 20, 29], help='Content layers')
parser.add_argument('--style_layers', nargs='+', type=int, default=[22], help='Style layers')
parser.add_argument('--lr', type=float, default=0.3, help='Learning rate')
parser.add_argument('--num_epochs', type=int, default=500, help='Number of epochs')
parser.add_argument('--lr_decay_epoch', type=int, default=50, help='Learning rate decay epoch')
parser.add_argument('--target', type=int, default=498, help='Target label for targeted attack')
parser.add_argument('--image_dir', type=str, default='output\\dog1\\suc_251.jpg', help='Path to image')

args = parser.parse_args()